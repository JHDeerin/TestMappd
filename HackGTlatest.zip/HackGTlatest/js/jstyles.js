
function myFunction() {
    alert("I am an alert box!");
}
